#!/bin/bash
# a shell script to recursively compare 2 directories, file by file (using sha1sum command)
# Original author: Jean-Claude Jouffre; modified by Kaze

# $ Step #1: chmod +x DIFFTREE.sh 
# $ Step #2: sudo cp DIFFTREE.sh /bin
# $ Step #3: sudo cp b3sum_linux_x64_bin /bin
# $ Step #4: DIFFTREE_BLAKE3.sh PATH1 [PATH2]

rvsn=4++

#var='    A  B C  '
#trail=${var##*[^[:blank:]]}    # get trailing space
#var=${var%${trail}}            # remove trailing space
#lead=${var%%[^[:blank:]]*}     # get leading space
#trim=${var#${lead}}            # remove leading space
#printf '++%s++\n' "$trim"
#Output:++A  B C++
#exit 1

trim_(){
	echo $@
}

# Above function is not perfect - it makes multi-spaces one space:
#fldNAM="   qq      6                ww   "
#ltrimmed="`trim_ "$fldNAM"`"
#echo "[""$ltrimmed""]"
#Output:[qq 6 ww]
#exit 1

GetCrntPth=`pwd`
GetDATE=`date`

prog=`basename $0`
if [ $# -ne 2 ] && [ $# -ne 1 ];then
	echo "Usage: $prog directory1 [directory2]"
	exit 1
fi

DIR1="$1"
DIR2="$2"

# We should remove the trailing '/' because basename generates two different strings, TAB in prompt adds it, but usually it is omitted:
if [ ${DIR1: -1} == "/" ] ; then
	lenofstr=${#DIR1}
	lenofstr=$((lenofstr-1)) 
	DIR3=${DIR1:0:lenofstr} # Caramba, why 0 and not 1?!
	DIR1=$DIR3
fi

if [ "$DIR2" == "" ] ; then
	DIR2="$DIR1"
fi

#if [ "$DIR1" = '' ]  ||  [ "$DIR2" = '' ];then 
#    echo "Usage: diffdir_recursion.sh PATH1 PATH2"
#    exit 1
#fi

BASENAME1=`basename "$DIR1"`
BASENAME2=`basename "$DIR2"`

f_error=/tmp/jcjerr.txt
f_list1=/tmp/jcjlst1.txt
f_list2=/tmp/jcjlst2.txt
f_temp=/tmp/jcjtmp.txt
rm -f $f_error $f_list1 $f_list2 $f_temp

echo -e "Running $prog script revision $rvsn,\nwritten originally by Jean-Claude Jouffre, modified by Kaze (suggestions for improvements on sanmayce@sanmayce.com)."
echo Note1: The resultant table is dumped \(also\) in \'Snapshot_$GetDATE.txt\' file.
echo Note2a: If both folders are the same then SHA1SUM column is added in order to have \"integrity check\" capability.
echo Note2b: If both folders are the same then \'REMOVE_DUPLETS.sh\' script is created - it deletes DUPLETs on running.
echo Note2c: If both folders are the same then \'"$BASENAME1".sha1.txt\' file is created - it contains the SHA1SUM snapshot of the tree.
echo Note2d: Once \'"$BASENAME1".sha1.txt\' is created, it is compared against \'Snapshot_$GetDATE.txt\', thus if identical then integrity is OK.

hasher="b3sum_linux_x64_bin"
b3sum_linux_x64_bin -V 2>$f_error
if [ $? -ne 0 ];then
	echo "Cannot find $hasher, using sha1sum instead."
	hasher="sha1sum"
fi
echo "Hasher in use: $hasher"

if [ "$DIR1" == "$DIR2" ] ; then
	echo "Adding SHA1SUM column..." # enforce CHECK-INTEGRITY mode i.e. making second tree the same
	echo "Enforcing CHECK-INTEGRITY mode."
else
	echo "Comparing $BASENAME1 and $BASENAME2 folders RECURSIVELY..."
fi

echo "Building lists of files..."

cd "$DIR1" 2>$f_error
if [ $? -ne 0 ];then
	echo "Failed to enter $DIR1, terminating."
	exit 2
fi
find * -type f -print > $f_list1 2>$f_error
if [ -s $f_list1 ];then
	sleep 1
else
	echo "Terminating, $DIR1 is empty."
	exit 2
fi

cd $GetCrntPth

cd "$DIR2" 2>$f_error
if [ $? -ne 0 ];then
	echo "Failed to enter $DIR2, terminating."
	exit 2
fi
find * -type f -print > $f_list2 2>$f_error
if [ -s $f_list2 ];then
	sleep 1
else
	echo "Terminating, $DIR2 is empty."
	exit 2
fi

cd $GetCrntPth

# this script shows how on exit the folder is not changed i.e. it is restored after changing [

#cd $1 2>/tmp/q
#if [ $? -ne 0 ];then
#	echo "Failed to enter $1, terminating."
#	exit 2
#fi
#pwd

#[sanmayce@fedora sourcecode_scripts]$ pwd
#/home/sanmayce/qb64/Trimasakari_benchmark_r2+/sourcecode_scripts
#[sanmayce@fedora sourcecode_scripts]$ sh enterfolder.sh tst/
#/home/sanmayce/qb64/Trimasakari_benchmark_r2+/sourcecode_scripts/tst
#[sanmayce@fedora sourcecode_scripts]$ pwd
#/home/sanmayce/qb64/Trimasakari_benchmark_r2+/sourcecode_scripts

# this script shows how on exit the folder is not changed i.e. it is restored after changing ]

echo "Sorting..."
sort $f_list1 > $f_temp 2>$f_error
mv $f_temp $f_list1
sort $f_list2 > $f_temp 2>$f_error
mv $f_temp $f_list2

comm -23 $f_list1 $f_list2 > $f_temp 2>$f_error
if [ -s $f_temp ] ; then
	echo
	echo "MISSING IN $DIR2 :"
	cat $f_temp
fi
comm -13 $f_list1 $f_list2 > $f_temp 2>$f_error
if [ -s $f_temp ] ; then
	echo
	echo "MISSING IN $DIR1 :"
	cat $f_temp
fi
echo
comm -12 $f_list1 $f_list2 > $f_temp 2>$f_error

echo "+------------+---------+-------------------------------------+-------------------+----------"
echo "| Status     | Number  | Time of last data modification      | Filesize          | Filename "
echo "+------------+---------+-------------------------------------+-------------------+----------"

					if [ "$DIR1" != "$DIR2" ] ; then
echo "+------------+---------+-------------------------------------+-------------------+----------" >"Snapshot_$GetDATE.txt"
echo "| Status     | Number  | Time of last data modification      | Filesize          | Filename " >>"Snapshot_$GetDATE.txt"
echo "+------------+---------+-------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
					fi

#list=$'One qqq\ntwo 12 455\nthree\nfour\n'
#while IFS= read -r line; do
#    echo "... $line ..."
#done <<< "$list"

#find * | while read line ; do
#   echo === $line ===
#done

# Grmbl, problema stands - how to read line-by-line into a variable...
AvoidSpaceTruncation=`cat $f_temp`
n=0
diffs=0
mfSALL=0

#for i in $AvoidSpaceTruncation ; do
while IFS= read -r i; do
	n=$(($n + 1 ))
	#f1=${DIR1}/$i
	#f2=${DIR2}/$i

	f1="$DIR1/$i"
	f2="$DIR2/$i"
	lenofstr=${#f1}

	j=`$hasher "$f1" 2>$f_error`
	if [ $? -ne 0 ] ; then
		echo "Error when md5sum $f1"
	else
		md1=`echo $j | awk '{ print $1 }' 2>$f_error`
		if [ $? -ne 0 ] ; then
			echo "Error when awk after md5sum $f1"
		else
			j=`$hasher "$f2" 2>$f_error`
			if [ $? -ne 0 ] ; then
				echo "Error when md5sum $f2"
			else
				md2=`echo $j | awk '{ print $1 }' 2>$f_error`
				if [ $? -ne 0 ] ; then
					echo "Error when awk after md5sum $f2"
				elif [ "$md1" != "$md2" ] ; then
					#echo "DIFFERENCE between $f1 and $f2 !" 
					#echo "DIFFERENCE: $i" 
					npad=$(printf %07d $n)
					mfM=`stat --format=%y "$f1"`
					mfS=`stat --format=%s "$f1"`

					mfSALL=$((mfSALL+mfS)) 

					mfSpad=$(printf %013d $mfS)
					#%x     time of last access, human-readable
					#%y     time of last data modification, human-readable
					#%z     time of last status change, human-readable

					#str="this is a string"
					#n=0
					#while read -n1 character; do
					#    n=$((n+1)); 
					#done < <(echo -n "$str")
					#echo "Length of the string is : $n "
					cc=0
					mfSpadCOMMA=''
					COMMA=','
					while read -n1 character; do
						cc=$((cc+1)) 
					# 9,123,123,123,123
					#  2   6   9   12
						if [ $cc == 1 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc == 4 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc == 7 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc = 10 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						else
							mfSpadCOMMA=$mfSpadCOMMA$character
						fi
					done < <(echo -n "$mfSpad")

					echo -n "| DIFFERENCE | $npad | $mfM | $mfSpadCOMMA | "$f1"" 
					echo #echo $lenofstr
					if [ "$DIR1" == "$DIR2" ] ; then
						echo "| DIFFERENCE | $npad | $md1 | $mfSpadCOMMA | "$f1"" >>"Snapshot_$GetDATE.txt"
					else
						echo "| DIFFERENCE | $npad | $mfM | $mfSpadCOMMA | "$f1"" >>"Snapshot_$GetDATE.txt"
					fi
					diffs=$(($diffs + 1 ))
				else
					#echo "OK        : $i" 
					npad=$(printf %07d $n)
					mfM=`stat --format=%y "$f1"`
					mfS=`stat --format=%s "$f1"`
				
					mfSALL=$((mfSALL+mfS)) 

					mfSpad=$(printf %013d $mfS)
					#%x     time of last access, human-readable
					#%y     time of last data modification, human-readable
					#%z     time of last status change, human-readable

					#str="this is a string"
					#n=0
					#while read -n1 character; do
					#    n=$((n+1)); 
					#done < <(echo -n "$str")
					#echo "Length of the string is : $n "
					cc=0
					mfSpadCOMMA=''
					COMMA=','
					while read -n1 character; do
						cc=$((cc+1)) 
					# 9,123,123,123,123
					#  2   6   9   12
						if [ $cc == 1 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc == 4 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc == 7 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						elif [ $cc = 10 ] ; then
							mfSpadCOMMA=$mfSpadCOMMA$character$COMMA
						else
							mfSpadCOMMA=$mfSpadCOMMA$character
						fi
					done < <(echo -n "$mfSpad")
					echo -n "| OK         | $npad | $mfM | $mfSpadCOMMA | "$f1"" 
					if [ "$DIR1" == "$DIR2" ] ; then
						echo "| OK         | $npad | $md1 | $mfSpadCOMMA | "$f1""  >>"Snapshot_$GetDATE.txt"
					else
						echo "| OK         | $npad | $mfM | $mfSpadCOMMA | "$f1""  >>"Snapshot_$GetDATE.txt"
					fi
					echo #echo $lenofstr
				fi
			fi
		fi
	fi
#done
done <<< "$AvoidSpaceTruncation"

rm -f $f_error $f_list1 $f_list2 $f_temp
echo "+------------+---------+-------------------------------------+-------------------+----------"

					if [ "$DIR1" != "$DIR2" ] ; then
echo "+------------+---------+-------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
					fi

echo "Total number of files          : $n (in $mfSALL bytes)"
echo "Total number of different files: $diffs"
					if [ "$DIR1" != "$DIR2" ] ; then
echo "Total number of files          : $n (in $mfSALL bytes)" >>"Snapshot_$GetDATE.txt"
echo "Total number of different files: $diffs" >>"Snapshot_$GetDATE.txt"
exit 0
					fi

sort --key=4 -t "|" "Snapshot_$GetDATE.txt" -o "Snapshot_$GetDATE.txt".sorted -T /tmp
fsums="Snapshot_$GetDATE.txt".sorted

if [ "$hasher" == "sha1sum" ] ; then
	echo "+--------+------------------------------------------+-------------------+----------" >"Snapshot_$GetDATE.txt"
	echo "| Status | SHA1SUM                                  | Filesize          | Filename " >>"Snapshot_$GetDATE.txt"
	echo "+--------+------------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
else
	echo "+--------+------------------------------------------------------------------+-------------------+----------" >"Snapshot_$GetDATE.txt"
	echo "| Status | BLAKE3SUM                                                        | Filesize          | Filename " >>"Snapshot_$GetDATE.txt"
	echo "+--------+------------------------------------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
fi

echo "#!/bin/bash">REMOVE_DUPLETS.sh
prvs=""
dups=0
mfSALL=0
TagDupletUnique=`cat "$fsums"`
while IFS= read -r i; do
	fldSUM=`echo "$i" | awk '{ print $6 }'`
	fldSIZ=`echo "$i" | awk '{ print $8 }'`
	fldNAM=`echo "$i" | awk '{ $1=$2=$3=$4=$5=$6=$7=$8=$9=""; print $0 }'`

# GRMBL, possible problem when having multiple internal spaces, they are converted to a single space by awk!

# Print all columns:
# awk '{print $0}' somefile
# Print all but the first column:
# awk '{$1=""; print $0}' somefile
# Print all but the first two columns:
# awk '{$1=$2=""; print $0}' somefile

	#ltrimmed="`trim_ "$fldNAM"`"
	lead=${fldNAM%%[^[:blank:]]*}     # get leading space
	ltrimmed=${fldNAM#${lead}}        # remove leading space

	if [ "$prvs" == "$fldSUM" ] ; then
		echo "rm \""$ltrimmed"\"" >>"REMOVE_DUPLETS.sh"
		dups=$((dups+1)) 
		echo "| DUPLET | $fldSUM | $fldSIZ | "$ltrimmed"" >>"Snapshot_$GetDATE.txt"

		mfS=`stat --format=%s "$ltrimmed"`
		mfSALL=$((mfSALL+mfS)) 

	else
		prvs=$fldSUM
		echo "|        | $fldSUM | $fldSIZ | "$ltrimmed"" >>"Snapshot_$GetDATE.txt"
	fi
done <<< "$TagDupletUnique"

if [ "$hasher" == "sha1sum" ] ; then
	echo "+--------+------------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
else
	echo "+--------+------------------------------------------------------------------+-------------------+----------" >>"Snapshot_$GetDATE.txt"
fi

echo "Total number of DUPLETs        : $dups (in $mfSALL bytes)"
echo
echo File \'"Snapshot_$GetDATE.txt"\' contains the DUPLETs \(DUPLICATIVE files\) in a roster.

if [ "$DIR1" == "$DIR2" ] ; then
	if [ $dups != 0 ] ; then
		echo File \'"REMOVE_DUPLETS.sh"\' removes all DUPLETs on running.
	fi
	echo Comparing \'"$BASENAME1".sha1.txt\' with \'"Snapshot_$GetDATE.txt"\' ...
	#diff -s "$BASENAME1".sha1.txt "Snapshot_$GetDATE.txt"
	RSLT=`diff -s "$BASENAME1".sha1.txt "Snapshot_$GetDATE.txt" 2>$f_error`
	if [ $? -ne 0 ] ; then
		diff -s "$BASENAME1".sha1.txt "Snapshot_$GetDATE.txt"
		echo The proper file \'"$BASENAME1".sha1.txt\' exists not, run the script once more.
	 	echo Updating \'"$BASENAME1".sha1.txt\' with \'"Snapshot_$GetDATE.txt"\' ...
		cp "Snapshot_$GetDATE.txt" "$BASENAME1".sha1.txt 
		echo "Result: Problematic/Grmbl."
		printf " __________                 ___.    .__                              __   .__               /\    ________                  ___.    .__    \n"
		printf " \______   \_______   ____  \_ |__  |  |    ____    _____  _____   _/  |_ |__|  ____       / /   /  _____/ _______   _____  \_ |__  |  |   \n"
		printf "  |     ___/\_  __ \ /  _ \  | __ \ |  |  _/ __ \  /     \ \__  \  \   __\|  |_/ ___\     / /   /   \  ___ \_  __ \ /     \  | __ \ |  |   \n"
		printf "  |    |     |  | \/(  <_> ) | \_\ \|  |__\  ___/ |  Y Y  \ / __ \_ |  |  |  |\  \___    / /    \    \_\  \ |  | \/|  Y Y  \ | \_\ \|  |__ \n"
		printf "  |____|     |__|    \____/  |___  /|____/ \___  >|__|_|  /(____  / |__|  |__| \___  >  / /      \______  / |__|   |__|_|  / |___  /|____/ \n"
		printf "                                 \/            \/       \/      \/                 \/   \/              \/               \/      \/        \n"
		exit 1
	fi
	if [ ${RSLT: -9} == "identical" ] ; then
		# should be ASCII art
		echo "Result: Identical/OK."
		printf "  .___     .___                  __   .__                 .__         /\  ________    ____  __. \n"
		printf "  |   |  __| _/  ____    ____  _/  |_ |__|  ____  _____   |  |       / /  \_____  \  |    |/ _| \n"
		printf "  |   | / __ | _/ __ \  /    \ \   __\|  |_/ ___\ \__  \  |  |      / /    /   |   \ |      <   \n"
		printf "  |   |/ /_/ | \  ___/ |   |  \ |  |  |  |\  \___  / __ \_|  |__   / /    /    |    \|    |  \  \n"
		printf "  |___|\____ |  \___  >|___|  / |__|  |__| \___  >(____  /|____/  / /     \_______  /|____|__ \ \n"
		printf "            \/      \/      \/                 \/      \/         \/              \/         \/ \n"                                           
	fi
fi

exit 0

#x=10
#y=20
#echo "x=10, y=5"  
#echo "Addition of x and y"  
#echo $(( $x + $y ))  
#echo "Subtraction of x and y"  
#echo $(( $x - $y ))  
#echo "Multiplication of x and y"  
#echo $(( $x * $y ))  
#echo "Division of x by y"  
#echo $(( $x / $y ))  
#echo "Exponentiation of x,y"  
#echo $(( $x ** $y ))  
#echo "Modular Division of x,y"  
#echo $(( $x % $y ))  
#echo "Incrementing x by 10, then x= "  
#(( x += 10 ))    
#echo $x  
#echo "Decrementing x by 15, then x= "  
#(( x -= 15 ))  
#echo $x  
#echo "Multiply of x by 2, then x="  
#(( x *= 2 ))  
#echo $x  
#echo "Dividing x by 5, x= "  
#(( x /= 5 ))  
#echo $x  
#echo "Remainder of Dividing x by 5, x="  
#(( x %= 5 ))  
#echo $x  

# An example (when folders are identical):
# 
# [sanmayce@djudjeto3 Music]$ ./diffdir_recursion.sh epiALTES_r5_INTERNAL-USE-ONLY epiALTES_r5_INTERNAL-USE-ONLY
# Running diffdir_recursion.sh script revision 3,
# written originally by Jean-Claude Jouffre, modified by Kaze (suggestions for improvements on sanmayce@sanmayce.com).
# Note1: The resultant table is dumped (also) in 'Snapshot_Sun Oct 29 07:03:31 PM EET 2023.txt' file.
# Note2: If both folders are the same then SHA1SUM column is added in order to have "integrity check" capability.
# Comparing epiALTES_r5_INTERNAL-USE-ONLY and epiALTES_r5_INTERNAL-USE-ONLY folders RECURSIVELY...
# Adding SHA1SUM column...
# Building lists of files...
# Sorting...
# 
# +------------+---------+-------------------------------------+-------------------+----------
# | Status     | Number  | Time of last data modification      | Filesize          | Filename 
# +------------+---------+-------------------------------------+-------------------+----------
# | OK         | 0000001 | 2021-08-04 16:34:46.000000000 +0300 | 0,000,000,022,879 | epiALTES_r5_INTERNAL-USE-ONLY/audio-headphones.png
# | OK         | 0000002 | 2023-04-02 12:03:47.000000000 +0300 | 0,000,009,882,334 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - B.B. King, B.B. King and Ruth Brown, Ruth Brown - You're the Boss.mp3
# | OK         | 0000003 | 2023-04-02 12:01:58.000000000 +0300 | 0,000,012,481,207 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Jerry Forney - Mississippi Ride.mp3
# | OK         | 0000004 | 2023-04-02 12:03:54.000000000 +0300 | 0,000,016,414,175 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Joe Bonamassa - Prisoner.mp3
# | OK         | 0000005 | 2023-04-02 12:03:03.000000000 +0300 | 0,000,012,359,961 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - John Verity Band - Say Why.mp3
# | OK         | 0000006 | 2023-04-02 12:03:37.000000000 +0300 | 0,000,012,738,218 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Zac Harmon - I'm a Healer.mp3
# | OK         | 0000007 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,453,926 | epiALTES_r5_INTERNAL-USE-ONLY/ColumnChart.ico
# | OK         | 0000008 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000009 | 2023-04-19 05:31:40.000000000 +0300 | 0,000,015,128,888 | epiALTES_r5_INTERNAL-USE-ONLY/DFT_2023.tar.gz
# | OK         | 0000010 | 2023-10-25 18:35:03.972211726 +0300 | 0,000,000,000,000 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.badfilenames.txt
# | OK         | 0000011 | 2023-06-12 10:27:41.000000000 +0300 | 0,000,000,118,365 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.bas
# | OK         | 0000012 | 2023-10-25 18:48:00.046418506 +0300 | 0,000,000,002,276 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.lst
# | OK         | 0000013 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,092,988 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.png
# | OK         | 0000014 | 2021-12-24 07:51:08.000000000 +0200 | 0,000,003,452,637 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.psd
# | OK         | 0000015 | 2023-06-20 07:32:53.000000000 +0300 | 0,000,003,511,304 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_12.2.1_O3_msse4.2.elf
# | OK         | 0000016 | 2023-06-12 10:28:42.000000000 +0300 | 0,000,005,338,624 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_8.1_O3_msse4.2.exe
# | OK         | 0000017 | 2023-04-22 06:24:41.000000000 +0300 | 0,000,369,954,272 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_simplescreenrecorder-2023-04-22_06.12.07.mkv
# | OK         | 0000018 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,000,007,154 | epiALTES_r5_INTERNAL-USE-ONLY/Liner.c
# | OK         | 0000019 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,050,660 | epiALTES_r5_INTERNAL-USE-ONLY/Mx437_CL_Stingray_8x16.ttf
# | OK         | 0000020 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,092,056 | epiALTES_r5_INTERNAL-USE-ONLY/Mx437_DOS-V_re_JPN24.ttf
# | OK         | 0000021 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,078,084 | epiALTES_r5_INTERNAL-USE-ONLY/Mx437_FMTowns_re_8x16-2x.ttf
# | OK         | 0000022 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,053,904 | epiALTES_r5_INTERNAL-USE-ONLY/Mx437_FMTowns_re_8x16.ttf
# | OK         | 0000023 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,039,672 | epiALTES_r5_INTERNAL-USE-ONLY/Mx437_ToshibaTxL2_8x8.ttf
# | OK         | 0000024 | 2023-06-12 07:49:26.000000000 +0300 | 0,000,000,085,216 | epiALTES_r5_INTERNAL-USE-ONLY/MxPlus_ToshibaTxL2_8x16_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000025 | 2021-06-09 00:01:48.000000000 +0300 | 0,000,000,146,744 | epiALTES_r5_INTERNAL-USE-ONLY/MxPlus_ToshibaTxL2_8x16.ttf
# | OK         | 0000026 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,015,876,480 | epiALTES_r5_INTERNAL-USE-ONLY/Ninja Resurrection - 01 - The Cant of Hell - At End.mp3
# | OK         | 0000027 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,028,600 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_CompaqThin_8x16.ttf
# | OK         | 0000028 | 2023-06-12 07:54:56.000000000 +0300 | 0,000,000,033,024 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000029 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,033,160 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400.ttf
# | OK         | 0000030 | 2023-06-12 07:52:14.000000000 +0300 | 0,000,000,025,884 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS_V_re._JPN12_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000031 | 2021-07-21 11:29:00.000000000 +0300 | 0,000,000,025,960 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS-V_re_JPN12.ttf
# | OK         | 0000032 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,023,900 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Portfolio_6x8.ttf
# | OK         | 0000033 | 2023-06-12 07:45:44.000000000 +0300 | 0,000,000,063,356 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000034 | 2020-11-21 02:02:00.000000000 +0200 | 0,000,000,063,852 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8.ttf
# | OK         | 0000035 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,000,002,003 | epiALTES_r5_INTERNAL-USE-ONLY/README.DIZ.txt
# | OK         | 0000036 | 2013-03-29 01:46:46.000000000 +0200 | 0,000,004,639,104 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Kazehana_kxrti_mifki.MP3
# | OK         | 0000037 | 2013-03-29 01:47:24.000000000 +0200 | 0,000,000,789,120 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Little_Bird.MP3
# | OK         | 0000038 | 2013-03-29 01:48:12.000000000 +0200 | 0,000,002,324,112 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_HanaSenpu.MP3
# | OK         | 0000039 | 2013-03-29 01:47:46.000000000 +0200 | 0,000,000,330,240 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_Kusano_grr.MP3
# | OK         | 0000040 | 2022-01-02 23:58:09.000000000 +0200 | 0,000,046,929,456 | epiALTES_r5_INTERNAL-USE-ONLY/[Suzi Quatro] Love's Gone Bad.flac.wav
# | OK         | 0000041 | 2021-12-31 16:00:26.000000000 +0200 | 0,000,010,642,696 | epiALTES_r5_INTERNAL-USE-ONLY/Suzi Quatro - Love's Gone Bad.mp3
# | OK         | 0000042 | 2023-04-11 06:11:40.000000000 +0300 | 0,000,061,423,660 | epiALTES_r5_INTERNAL-USE-ONLY/Vanessa Paradis - M & J 1988(LP) - Marilyn & John.flac.wav
# | OK         | 0000043 | 2023-05-20 05:53:52.000000000 +0300 | 0,000,032,317,484 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb_1080p.mp4.wav
# | OK         | 0000044 | 2023-05-20 05:23:31.000000000 +0300 | 0,000,031,117,356 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb - Flint Remix_1080p.mp4.wav
# | OK         | 0000045 | 2021-12-31 09:28:26.000000000 +0200 | 0,000,002,156,388 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Danger Snow.mp3
# | OK         | 0000046 | 2023-06-09 03:54:00.000000000 +0300 | 0,000,095,609,982 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4
# | OK         | 0000047 | 2023-06-09 06:34:30.000000000 +0300 | 0,000,031,821,868 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4.wav
# | OK         | 0000048 | 2021-12-31 09:37:50.000000000 +0200 | 0,000,003,669,818 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Diablo Guitar Cover - Tristram - Super Guitar Bros.mp3
# | OK         | 0000049 | 2023-06-10 10:14:42.000000000 +0300 | 0,000,122,011,104 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4
# | OK         | 0000050 | 2023-06-12 08:06:48.000000000 +0300 | 0,000,040,611,884 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4.wav
# | OK         | 0000051 | 2023-06-01 21:37:37.000000000 +0300 | 0,000,037,523,500 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - The Underground feat Sapir Shoval_1080p.mp4.wav
# | OK         | 0000052 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccccccc.mp3
# | OK         | 0000053 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccc.mp3
# | OK         | 0000054 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000055 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/rrrrrrrrrrrrrrrrr.mp3
# | OK         | 0000056 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ttttttttttttttttt.mp3
# | OK         | 0000057 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/yyyyyyyyy.mp3
# +------------+---------+-------------------------------------+-------------------+----------
# Total number of files          : 57
# Total number of different files: 0
# 
# File 'Snapshot_Sun Oct 29 07:03:31 PM EET 2023.txt' contains the DUPLICATIVE files in a roster.
# [sanmayce@djudjeto3 Music]$ cat "Snapshot_Sun Oct 29 07:03:31 PM EET 2023.txt"
# +--------+------------------------------------------+-------------------+----------
# | Status | SHA1SUM                                  | Filesize          | Filename 
# +--------+------------------------------------------+-------------------+----------
# |        | 0138195861532e19d3470843c30077caa71c67c5 | 0,000,046,929,456 |  epiALTES_r5_INTERNAL-USE-ONLY/[Suzi Quatro] Love's Gone Bad.flac.wav
# |        | 071a11ac464ad42909c124407fbda55ac11a6287 | 0,000,000,118,365 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.bas
# |        | 11a2b803130f0dce8c2f81e671400521e4072d30 | 0,000,012,738,218 |  epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Zac Harmon - I'm a Healer.mp3
# |        | 1472833d9a305d1afa66b9eb0d0c994d80de2c2e | 0,000,000,039,672 |  epiALTES_r5_INTERNAL-USE-ONLY/Mx437_ToshibaTxL2_8x8.ttf
# |        | 18d6dd119f129a41df557248550a392ef46b71fd | 0,000,000,063,852 |  epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8.ttf
# |        | 19518fbab297506eb15f544f6894bdd15742d605 | 0,000,031,117,356 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb - Flint Remix_1080p.mp4.wav
# |        | 1fe4146e46786856aa68a91e7b4c0fa6e09e3635 | 0,000,003,669,818 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Diablo Guitar Cover - Tristram - Super Guitar Bros.mp3
# |        | 21fd2a32fac3c89c744a4d2b86d316a4af2f8a14 | 0,000,000,002,003 |  epiALTES_r5_INTERNAL-USE-ONLY/README.DIZ.txt
# |        | 251087421c2c982454b25be9edcfbfdea9da475c | 0,000,014,789,593 |  epiALTES_r5_INTERNAL-USE-ONLY/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | DUPLET | 251087421c2c982454b25be9edcfbfdea9da475c | 0,000,014,789,593 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# |        | 25e8ecb3e55de45d3ecadd9a3e1aa4b23973e4fc | 0,000,004,639,104 |  epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Kazehana_kxrti_mifki.MP3
# |        | 304f1282a3115293afa655a829fbfb9c77366011 | 0,000,000,002,276 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.lst
# |        | 325489da9677e8843c45ea2e466cb0a70ddd16a4 | 0,000,015,128,888 |  epiALTES_r5_INTERNAL-USE-ONLY/DFT_2023.tar.gz
# |        | 345e73120ee22058fcb399b66b7f32fdcc8bb72a | 0,000,000,025,960 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS-V_re_JPN12.ttf
# |        | 35e1f01c852820055653a36012abbd0cd0b61948 | 0,000,009,882,334 |  epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - B.B. King, B.B. King and Ruth Brown, Ruth Brown - You're the Boss.mp3
# |        | 4002d4c0f45d29ffe82bdc51197a0d7089387f88 | 0,000,000,053,904 |  epiALTES_r5_INTERNAL-USE-ONLY/Mx437_FMTowns_re_8x16.ttf
# |        | 40de74b3758aa8c592b4fa4e8876b40ee3f4b2d1 | 0,000,002,324,112 |  epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_HanaSenpu.MP3
# |        | 44317669576d578d23f306fd8f382f8952817b3e | 0,000,010,642,696 |  epiALTES_r5_INTERNAL-USE-ONLY/Suzi Quatro - Love's Gone Bad.mp3
# |        | 447dfbf899d766851a087f778408f6a8eeb84c2b | 0,000,002,156,388 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Danger Snow.mp3
# |        | 49d13021289d4a2c38ab5e67ca84dce6257a5881 | 0,000,005,338,624 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_8.1_O3_msse4.2.exe
# |        | 530920098cdf9ac3bfa8afdb422d4519e58e8a90 | 0,000,040,611,884 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4.wav
# |        | 5430bd020f1dcfdd3957a19e7662d559ebabd251 | 0,000,037,523,500 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - The Underground feat Sapir Shoval_1080p.mp4.wav
# |        | 54ce1e31a8e87723ec1d4fb20e7264ef3a9a35f0 | 0,000,000,050,660 |  epiALTES_r5_INTERNAL-USE-ONLY/Mx437_CL_Stingray_8x16.ttf
# |        | 555206b85c6e1311d58b836d53d7fa390e35b6d4 | 0,000,000,028,600 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_CompaqThin_8x16.ttf
# |        | 5908ca91fb8e0c40a163796fbea5fee7089a389b | 0,000,031,821,868 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4.wav
# |        | 5de427b2600e17411628cc6cea722ececc3e2c67 | 0,000,007,918,851 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccc.mp3
# | DUPLET | 5de427b2600e17411628cc6cea722ececc3e2c67 | 0,000,007,918,851 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/rrrrrrrrrrrrrrrrr.mp3
# |        | 5fd5a982324f762c64e4b9e60e0833790248e229 | 0,000,009,599,208 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccccccc.mp3
# | DUPLET | 5fd5a982324f762c64e4b9e60e0833790248e229 | 0,000,009,599,208 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ttttttttttttttttt.mp3
# | DUPLET | 5fd5a982324f762c64e4b9e60e0833790248e229 | 0,000,009,599,208 |  epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/yyyyyyyyy.mp3
# |        | 6c3d9a20b56e35d8f0e2a9a6f3b47dddaceae4e7 | 0,000,000,085,216 |  epiALTES_r5_INTERNAL-USE-ONLY/MxPlus_ToshibaTxL2_8x16_halfboxes-higher-trimmed-at-right.ttf
# |        | 7897080ba83f78b448a67e9feed9563fe7883b2b | 0,000,369,954,272 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_simplescreenrecorder-2023-04-22_06.12.07.mkv
# |        | 7a6ea41e43d55ea9526945199e1ae33ae94d19ba | 0,000,016,414,175 |  epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Joe Bonamassa - Prisoner.mp3
# |        | 7d3376fb3143212657df6085479e7b433a6a091d | 0,000,000,007,154 |  epiALTES_r5_INTERNAL-USE-ONLY/Liner.c
# |        | afa6c644ca84139441c085e573be56d77e99750c | 0,000,000,033,024 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400_halfboxes-higher-trimmed-at-right.ttf
# |        | b58ffed02be957f9a74c7c2e476b152fd0c12a94 | 0,000,003,452,637 |  epiALTES_r5_INTERNAL-USE-ONLY/epialtes.psd
# |        | b776b5567d0b2d04b5f9ded40658626cda5a54cc | 0,000,061,423,660 |  epiALTES_r5_INTERNAL-USE-ONLY/Vanessa Paradis - M & J 1988(LP) - Marilyn & John.flac.wav
# |        | b926174ddc3e495675e4928c86f08ae4063141c5 | 0,000,122,011,104 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4
# |        | baa9577ec8ef27be02530dd6f68478bbcbdd4e62 | 0,000,000,789,120 |  epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Little_Bird.MP3
# |        | bd386f2043baff562598214c662624b4f52cbdb0 | 0,000,000,092,056 |  epiALTES_r5_INTERNAL-USE-ONLY/Mx437_DOS-V_re_JPN24.ttf
# |        | be6739673da2cff1701840af6eb506148de228fe | 0,000,012,481,207 |  epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Jerry Forney - Mississippi Ride.mp3
# |        | c1d062ace11a67abe3e70a1331576790ac85db0e | 0,000,015,876,480 |  epiALTES_r5_INTERNAL-USE-ONLY/Ninja Resurrection - 01 - The Cant of Hell - At End.mp3
# |        | c5092841fcb20cdf80ae0c651122e36f34ea9b27 | 0,000,000,330,240 |  epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_Kusano_grr.MP3
# |        | cd974f597a41926b0317819348690a2c72239ad9 | 0,000,032,317,484 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb_1080p.mp4.wav
# |        | d527fdd73475e95d0910bc7f1f9c3d73561da343 | 0,000,000,078,084 |  epiALTES_r5_INTERNAL-USE-ONLY/Mx437_FMTowns_re_8x16-2x.ttf
# |        | d65b04a2c0dbf3f0b9c35b1cb6a08ee7621c3153 | 0,000,000,033,160 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400.ttf
# |        | d74df0d31d5edcf46bc0918e6d6fd4b0c92d0d18 | 0,000,001,453,926 |  epiALTES_r5_INTERNAL-USE-ONLY/ColumnChart.ico
# |        | d88a8a060883a1faf39e22d7b8bb3520ddcbbd12 | 0,000,000,022,879 |  epiALTES_r5_INTERNAL-USE-ONLY/audio-headphones.png
# |        | da39a3ee5e6b4b0d3255bfef95601890afd80709 | 0,000,000,000,000 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.badfilenames.txt
# |        | de4050915ab3cbca1d9cca07d962d6b9cdba3b7c | 0,000,000,023,900 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_Portfolio_6x8.ttf
# |        | e630dc29462d4b39fe77189ec7b0641f32f1c7ed | 0,000,000,063,356 |  epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8_halfboxes-higher-trimmed-at-right.ttf
# |        | ea79b3fe3435002a348150f225b377233111cf14 | 0,000,003,511,304 |  epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_12.2.1_O3_msse4.2.elf
# |        | ec56fca198caa091a404cde771ee70dfdb63567c | 0,000,095,609,982 |  epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4
# |        | ef05f0e0ed3c573b4e915071cec727d356fdabb2 | 0,000,000,146,744 |  epiALTES_r5_INTERNAL-USE-ONLY/MxPlus_ToshibaTxL2_8x16.ttf
# |        | f251b1c27e4ebd146d1f3e5a78904e390e0d1294 | 0,000,001,092,988 |  epiALTES_r5_INTERNAL-USE-ONLY/epialtes.png
# |        | fb056c2b63f38986cca779e889207381706d682b | 0,000,012,359,961 |  epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - John Verity Band - Say Why.mp3
# |        | fcc1c9b7475b322036dcbf4303fb4df58e958ebc | 0,000,000,025,884 |  epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS_V_re._JPN12_halfboxes-higher-trimmed-at-right.ttf
# +--------+------------------------------------------+-------------------+----------
# [sanmayce@djudjeto3 Music]$ 

# An example (when folders are NOT identical):
# 
# [sanmayce@djudjeto3 Music]$ ./diffdir_recursion.sh epiALTES_r5_INTERNAL-USE-ONLY selection/epiALTES_r5_INTERNAL-USE-ONLY2
# Running diffdir_recursion.sh script revision 3,
# written originally by Jean-Claude Jouffre, modified by Kaze (suggestions for improvements on sanmayce@sanmayce.com).
# Note1: The resultant table is dumped (also) in 'Snapshot_Sun Oct 29 07:16:41 PM EET 2023.txt' file.
# Note2: If both folders are the same then SHA1SUM column is added in order to have "integrity check" capability.
# Comparing epiALTES_r5_INTERNAL-USE-ONLY and epiALTES_r5_INTERNAL-USE-ONLY2 folders RECURSIVELY...
# Building lists of files...
# Sorting...
# 
# MISSING IN selection/epiALTES_r5_INTERNAL-USE-ONLY2 :
# Liner.c
# Mx437_CL_Stingray_8x16.ttf
# Mx437_DOS-V_re_JPN24.ttf
# Mx437_FMTowns_re_8x16-2x.ttf
# Mx437_FMTowns_re_8x16.ttf
# Mx437_ToshibaTxL2_8x8.ttf
# MxPlus_ToshibaTxL2_8x16_halfboxes-higher-trimmed-at-right.ttf
# MxPlus_ToshibaTxL2_8x16.ttf
# 
# MISSING IN epiALTES_r5_INTERNAL-USE-ONLY :
# Fun Fun - White night city lights (1987).flac
# Keb' Mo' - Slow down.flac
# 
# +------------+---------+-------------------------------------+-------------------+----------
# | Status     | Number  | Time of last data modification      | Filesize          | Filename 
# +------------+---------+-------------------------------------+-------------------+----------
# | OK         | 0000001 | 2021-08-04 16:34:46.000000000 +0300 | 0,000,000,022,879 | epiALTES_r5_INTERNAL-USE-ONLY/audio-headphones.png
# | OK         | 0000002 | 2023-04-02 12:03:47.000000000 +0300 | 0,000,009,882,334 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - B.B. King, B.B. King and Ruth Brown, Ruth Brown - You're the Boss.mp3
# | OK         | 0000003 | 2023-04-02 12:01:58.000000000 +0300 | 0,000,012,481,207 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Jerry Forney - Mississippi Ride.mp3
# | OK         | 0000004 | 2023-04-02 12:03:54.000000000 +0300 | 0,000,016,414,175 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Joe Bonamassa - Prisoner.mp3
# | OK         | 0000005 | 2023-04-02 12:03:03.000000000 +0300 | 0,000,012,359,961 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - John Verity Band - Say Why.mp3
# | OK         | 0000006 | 2023-04-02 12:03:37.000000000 +0300 | 0,000,012,738,218 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Zac Harmon - I'm a Healer.mp3
# | OK         | 0000007 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,453,926 | epiALTES_r5_INTERNAL-USE-ONLY/ColumnChart.ico
# | OK         | 0000008 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000009 | 2023-04-19 05:31:40.000000000 +0300 | 0,000,015,128,888 | epiALTES_r5_INTERNAL-USE-ONLY/DFT_2023.tar.gz
# | OK         | 0000010 | 2023-10-25 18:35:03.972211726 +0300 | 0,000,000,000,000 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.badfilenames.txt
# | OK         | 0000011 | 2023-06-12 10:27:41.000000000 +0300 | 0,000,000,118,365 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.bas
# | OK         | 0000012 | 2023-10-25 18:48:00.046418506 +0300 | 0,000,000,002,276 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.lst
# | OK         | 0000013 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,092,988 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.png
# | OK         | 0000014 | 2021-12-24 07:51:08.000000000 +0200 | 0,000,003,452,637 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.psd
# | OK         | 0000015 | 2023-06-20 07:32:53.000000000 +0300 | 0,000,003,511,304 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_12.2.1_O3_msse4.2.elf
# | OK         | 0000016 | 2023-06-12 10:28:42.000000000 +0300 | 0,000,005,338,624 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_8.1_O3_msse4.2.exe
# | OK         | 0000017 | 2023-04-22 06:24:41.000000000 +0300 | 0,000,369,954,272 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_simplescreenrecorder-2023-04-22_06.12.07.mkv
# | OK         | 0000018 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,015,876,480 | epiALTES_r5_INTERNAL-USE-ONLY/Ninja Resurrection - 01 - The Cant of Hell - At End.mp3
# | OK         | 0000019 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,028,600 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_CompaqThin_8x16.ttf
# | OK         | 0000020 | 2023-06-12 07:54:56.000000000 +0300 | 0,000,000,033,024 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000021 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,033,160 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400.ttf
# | OK         | 0000022 | 2023-06-12 07:52:14.000000000 +0300 | 0,000,000,025,884 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS_V_re._JPN12_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000023 | 2021-07-21 11:29:00.000000000 +0300 | 0,000,000,025,960 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS-V_re_JPN12.ttf
# | OK         | 0000024 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,023,900 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Portfolio_6x8.ttf
# | OK         | 0000025 | 2023-06-12 07:45:44.000000000 +0300 | 0,000,000,063,356 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000026 | 2020-11-21 02:02:00.000000000 +0200 | 0,000,000,063,852 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8.ttf
# | DIFFERENCE | 0000027 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,000,002,003 | epiALTES_r5_INTERNAL-USE-ONLY/README.DIZ.txt
# | OK         | 0000028 | 2013-03-29 01:46:46.000000000 +0200 | 0,000,004,639,104 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Kazehana_kxrti_mifki.MP3
# | OK         | 0000029 | 2013-03-29 01:47:24.000000000 +0200 | 0,000,000,789,120 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Little_Bird.MP3
# | OK         | 0000030 | 2013-03-29 01:48:12.000000000 +0200 | 0,000,002,324,112 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_HanaSenpu.MP3
# | OK         | 0000031 | 2013-03-29 01:47:46.000000000 +0200 | 0,000,000,330,240 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_Kusano_grr.MP3
# | OK         | 0000032 | 2022-01-02 23:58:09.000000000 +0200 | 0,000,046,929,456 | epiALTES_r5_INTERNAL-USE-ONLY/[Suzi Quatro] Love's Gone Bad.flac.wav
# | OK         | 0000033 | 2021-12-31 16:00:26.000000000 +0200 | 0,000,010,642,696 | epiALTES_r5_INTERNAL-USE-ONLY/Suzi Quatro - Love's Gone Bad.mp3
# | OK         | 0000034 | 2023-04-11 06:11:40.000000000 +0300 | 0,000,061,423,660 | epiALTES_r5_INTERNAL-USE-ONLY/Vanessa Paradis - M & J 1988(LP) - Marilyn & John.flac.wav
# | OK         | 0000035 | 2023-05-20 05:53:52.000000000 +0300 | 0,000,032,317,484 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb_1080p.mp4.wav
# | OK         | 0000036 | 2023-05-20 05:23:31.000000000 +0300 | 0,000,031,117,356 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb - Flint Remix_1080p.mp4.wav
# | OK         | 0000037 | 2021-12-31 09:28:26.000000000 +0200 | 0,000,002,156,388 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Danger Snow.mp3
# | OK         | 0000038 | 2023-06-09 03:54:00.000000000 +0300 | 0,000,095,609,982 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4
# | OK         | 0000039 | 2023-06-09 06:34:30.000000000 +0300 | 0,000,031,821,868 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4.wav
# | OK         | 0000040 | 2021-12-31 09:37:50.000000000 +0200 | 0,000,003,669,818 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Diablo Guitar Cover - Tristram - Super Guitar Bros.mp3
# | OK         | 0000041 | 2023-06-10 10:14:42.000000000 +0300 | 0,000,122,011,104 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4
# | OK         | 0000042 | 2023-06-12 08:06:48.000000000 +0300 | 0,000,040,611,884 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4.wav
# | OK         | 0000043 | 2023-06-01 21:37:37.000000000 +0300 | 0,000,037,523,500 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - The Underground feat Sapir Shoval_1080p.mp4.wav
# | OK         | 0000044 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccccccc.mp3
# | OK         | 0000045 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccc.mp3
# | OK         | 0000046 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000047 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/rrrrrrrrrrrrrrrrr.mp3
# | OK         | 0000048 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ttttttttttttttttt.mp3
# | OK         | 0000049 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/yyyyyyyyy.mp3
# +------------+---------+-------------------------------------+-------------------+----------
# Total number of files          : 49
# Total number of different files: 1
# [sanmayce@djudjeto3 Music]$ cat "Snapshot_Sun Oct 29 07:16:41 PM EET 2023.txt"
# +------------+---------+-------------------------------------+-------------------+----------
# | Status     | Number  | Time of last data modification      | Filesize          | Filename 
# +------------+---------+-------------------------------------+-------------------+----------
# | OK         | 0000001 | 2021-08-04 16:34:46.000000000 +0300 | 0,000,000,022,879 | epiALTES_r5_INTERNAL-USE-ONLY/audio-headphones.png
# | OK         | 0000002 | 2023-04-02 12:03:47.000000000 +0300 | 0,000,009,882,334 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - B.B. King, B.B. King and Ruth Brown, Ruth Brown - You're the Boss.mp3
# | OK         | 0000003 | 2023-04-02 12:01:58.000000000 +0300 | 0,000,012,481,207 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Jerry Forney - Mississippi Ride.mp3
# | OK         | 0000004 | 2023-04-02 12:03:54.000000000 +0300 | 0,000,016,414,175 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Joe Bonamassa - Prisoner.mp3
# | OK         | 0000005 | 2023-04-02 12:03:03.000000000 +0300 | 0,000,012,359,961 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - John Verity Band - Say Why.mp3
# | OK         | 0000006 | 2023-04-02 12:03:37.000000000 +0300 | 0,000,012,738,218 | epiALTES_r5_INTERNAL-USE-ONLY/Blues & Rock Relax Ballads (2CD) (2023) - Zac Harmon - I'm a Healer.mp3
# | OK         | 0000007 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,453,926 | epiALTES_r5_INTERNAL-USE-ONLY/ColumnChart.ico
# | OK         | 0000008 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000009 | 2023-04-19 05:31:40.000000000 +0300 | 0,000,015,128,888 | epiALTES_r5_INTERNAL-USE-ONLY/DFT_2023.tar.gz
# | OK         | 0000010 | 2023-10-25 18:35:03.972211726 +0300 | 0,000,000,000,000 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.badfilenames.txt
# | OK         | 0000011 | 2023-06-12 10:27:41.000000000 +0300 | 0,000,000,118,365 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.bas
# | OK         | 0000012 | 2023-10-25 18:48:00.046418506 +0300 | 0,000,000,002,276 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES.lst
# | OK         | 0000013 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,001,092,988 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.png
# | OK         | 0000014 | 2021-12-24 07:51:08.000000000 +0200 | 0,000,003,452,637 | epiALTES_r5_INTERNAL-USE-ONLY/epialtes.psd
# | OK         | 0000015 | 2023-06-20 07:32:53.000000000 +0300 | 0,000,003,511,304 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_12.2.1_O3_msse4.2.elf
# | OK         | 0000016 | 2023-06-12 10:28:42.000000000 +0300 | 0,000,005,338,624 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_r5_v2.0.2_GCC_8.1_O3_msse4.2.exe
# | OK         | 0000017 | 2023-04-22 06:24:41.000000000 +0300 | 0,000,369,954,272 | epiALTES_r5_INTERNAL-USE-ONLY/epiALTES_simplescreenrecorder-2023-04-22_06.12.07.mkv
# | OK         | 0000018 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,015,876,480 | epiALTES_r5_INTERNAL-USE-ONLY/Ninja Resurrection - 01 - The Cant of Hell - At End.mp3
# | OK         | 0000019 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,028,600 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_CompaqThin_8x16.ttf
# | OK         | 0000020 | 2023-06-12 07:54:56.000000000 +0300 | 0,000,000,033,024 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000021 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,033,160 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Cordata_PPC-400.ttf
# | OK         | 0000022 | 2023-06-12 07:52:14.000000000 +0300 | 0,000,000,025,884 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS_V_re._JPN12_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000023 | 2021-07-21 11:29:00.000000000 +0300 | 0,000,000,025,960 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_DOS-V_re_JPN12.ttf
# | OK         | 0000024 | 2023-01-10 20:27:03.000000000 +0200 | 0,000,000,023,900 | epiALTES_r5_INTERNAL-USE-ONLY/Px437_Portfolio_6x8.ttf
# | OK         | 0000025 | 2023-06-12 07:45:44.000000000 +0300 | 0,000,000,063,356 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8_halfboxes-higher-trimmed-at-right.ttf
# | OK         | 0000026 | 2020-11-21 02:02:00.000000000 +0200 | 0,000,000,063,852 | epiALTES_r5_INTERNAL-USE-ONLY/PxPlus_ToshibaSat_8x8.ttf
# | DIFFERENCE | 0000027 | 2022-05-20 04:57:53.000000000 +0300 | 0,000,000,002,003 | epiALTES_r5_INTERNAL-USE-ONLY/README.DIZ.txt
# | OK         | 0000028 | 2013-03-29 01:46:46.000000000 +0200 | 0,000,004,639,104 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Kazehana_kxrti_mifki.MP3
# | OK         | 0000029 | 2013-03-29 01:47:24.000000000 +0200 | 0,000,000,789,120 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E03_Little_Bird.MP3
# | OK         | 0000030 | 2013-03-29 01:48:12.000000000 +0200 | 0,000,002,324,112 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_HanaSenpu.MP3
# | OK         | 0000031 | 2013-03-29 01:47:46.000000000 +0200 | 0,000,000,330,240 | epiALTES_r5_INTERNAL-USE-ONLY/Sekirei_E04_Kusano_grr.MP3
# | OK         | 0000032 | 2022-01-02 23:58:09.000000000 +0200 | 0,000,046,929,456 | epiALTES_r5_INTERNAL-USE-ONLY/[Suzi Quatro] Love's Gone Bad.flac.wav
# | OK         | 0000033 | 2021-12-31 16:00:26.000000000 +0200 | 0,000,010,642,696 | epiALTES_r5_INTERNAL-USE-ONLY/Suzi Quatro - Love's Gone Bad.mp3
# | OK         | 0000034 | 2023-04-11 06:11:40.000000000 +0300 | 0,000,061,423,660 | epiALTES_r5_INTERNAL-USE-ONLY/Vanessa Paradis - M & J 1988(LP) - Marilyn & John.flac.wav
# | OK         | 0000035 | 2023-05-20 05:53:52.000000000 +0300 | 0,000,032,317,484 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb_1080p.mp4.wav
# | OK         | 0000036 | 2023-05-20 05:23:31.000000000 +0300 | 0,000,031,117,356 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Bomb - Flint Remix_1080p.mp4.wav
# | OK         | 0000037 | 2021-12-31 09:28:26.000000000 +0200 | 0,000,002,156,388 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Danger Snow.mp3
# | OK         | 0000038 | 2023-06-09 03:54:00.000000000 +0300 | 0,000,095,609,982 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4
# | OK         | 0000039 | 2023-06-09 06:34:30.000000000 +0300 | 0,000,031,821,868 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - DEEP ZONE Project Balthazar DJ Take Me Away HD Remastered 2023 BG Eurovision Winner 2008_1080p.mp4.wav
# | OK         | 0000040 | 2021-12-31 09:37:50.000000000 +0200 | 0,000,003,669,818 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Diablo Guitar Cover - Tristram - Super Guitar Bros.mp3
# | OK         | 0000041 | 2023-06-10 10:14:42.000000000 +0300 | 0,000,122,011,104 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4
# | OK         | 0000042 | 2023-06-12 08:06:48.000000000 +0300 | 0,000,040,611,884 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - Fierce Angel Presents Substitute Mirifico Ft Sam Obernik_1080p.mp4.wav
# | OK         | 0000043 | 2023-06-01 21:37:37.000000000 +0300 | 0,000,037,523,500 | epiALTES_r5_INTERNAL-USE-ONLY/y2mate.com - The Underground feat Sapir Shoval_1080p.mp4.wav
# | OK         | 0000044 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccccccc.mp3
# | OK         | 0000045 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ccccc.mp3
# | OK         | 0000046 | 2021-07-10 08:50:40.000000000 +0300 | 0,000,014,789,593 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/Curacao - Yiasou (Especial Russian Mix) (6m 09s).mp3
# | OK         | 0000047 | 2023-07-13 08:07:26.998404834 +0300 | 0,000,007,918,851 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/rrrrrrrrrrrrrrrrr.mp3
# | OK         | 0000048 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/ttttttttttttttttt.mp3
# | OK         | 0000049 | 2023-07-13 08:04:04.169605425 +0300 | 0,000,009,599,208 | epiALTES_r5_INTERNAL-USE-ONLY/zzzzzzzzzzzzzzzz/yyyyyyyyy.mp3
# +------------+---------+-------------------------------------+-------------------+----------
# Total number of files          : 49
# Total number of different files: 1
# [sanmayce@djudjeto3 Music]$ 

